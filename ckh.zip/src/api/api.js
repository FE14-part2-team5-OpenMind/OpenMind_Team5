const BASE_URL = 'https://openmind-api.vercel.app/14-5';

export const ENDPOINTS = {
  mypage: `${BASE_URL}/subjects/`,
};
